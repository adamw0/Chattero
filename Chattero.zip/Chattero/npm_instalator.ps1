# Instalacja zaleznosci backendu (katalog główny)
Write-Host "Instaluje zaleznosci backendu..."
cd backend
npm install

# Instalacja mongodb-memory-server w backendzie
Write-Host "Instaluje mongodb-memory-server w backendzie..."
npm install mongodb-memory-server --save

# Instalacja zaleznosci frontendu
Write-Host "Instaluje zaleznosci frontendu..."
cd ../frontend
npm install
cd ..
